#include "../modules/control_attitude/control_attitude.h"

static float _gyro_z = 0;
static float _angle = 0;

void control_attitude_main(void)
{
		
}
