#pragma once

void auto_disarming_main(void);
void auto_disarming_clear_cnt(void);
