#pragma once
#include "stm32f1xx_hal.h"

void auto_disarming_main(void);
void auto_disarming_clear_cnt(void);
