/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H__
#define __MAIN_H__

/* Includes ------------------------------------------------------------------*/

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private define ------------------------------------------------------------*/

#define i2c_pin_scl_Pin GPIO_PIN_10
#define i2c_pin_scl_GPIO_Port GPIOB
#define i2c_pin_sda_Pin GPIO_PIN_11
#define i2c_pin_sda_GPIO_Port GPIOB
#define MOTORA2_Pin GPIO_PIN_4
#define MOTORA2_GPIO_Port GPIOB
#define MOTORA1_Pin GPIO_PIN_5
#define MOTORA1_GPIO_Port GPIOB
#define MOTORB1_Pin GPIO_PIN_6
#define MOTORB1_GPIO_Port GPIOB
#define MOTORB2_Pin GPIO_PIN_7
#define MOTORB2_GPIO_Port GPIOB

/* ########################## Assert Selection ############################## */
/**
  * @brief Uncomment the line below to expanse the "assert_param" macro in the 
  *        HAL drivers code
  */
/* #define USE_FULL_ASSERT    1U */

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
 extern "C" {
#endif
void _Error_Handler(char *, int);

#define Error_Handler() _Error_Handler(__FILE__, __LINE__)
#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H__ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
